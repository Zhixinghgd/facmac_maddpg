# Release Notes

```{eval-rst}
.. changelog::
    :github: https://github.com/Farama-Foundation/PettingZoo/releases
    :pypi: https://pypi.org/project/pettingzoo/
    :changelog-url:
```
